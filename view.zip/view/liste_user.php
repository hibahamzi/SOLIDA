<?php
require_once "../model/User.php";

$userModel = new User();
$users = $userModel->getAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Liste users</title>
</head>
<body>
<h2>Liste des users</h2>
<a href="../controller/UserController.php?action=ajout">Ajouter user</a>
<link rel="stylesheet" href="assets/css/tab.css">
<table border="1">
    <tr>
        <th>ID</th>
        <th>Nom</th>
        <th>Prénom</th>
        <th>Email</th>
        <th>Region</th>       
        <th>Mot de passe (crypté)</th>
        <th>Actions</th>
    </tr>
    <?php foreach($users as $u): ?>
    <tr>
        <td><?php echo $u['id']; ?></td>
        <td><?php echo $u['nom']; ?></td>
        <td><?php echo $u['prenom']; ?></td>
        <td><?php echo $u['email']; ?></td>
        <td><?php echo $u['region']; ?></td>
        <td><?php echo $u['pwd']; ?></td>
        <td>
            <a href="../controller/UserController.php?action=modifier&id=<?php echo $u['id']; ?>">Modifier</a> |
            <a href="../controller/UserController.php?action=supprimer&id=<?php echo $u['id']; ?>" onclick="return confirm('Supprimer user ?')">Supprimer</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
</body>
</html>
