<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Ajouter user</title>
</head>
<body>
<h2>Ajouter user</h2>
<form method="post" action="../controller/UserController.php?action=ajout">
    <input type="text" name="nom" placeholder="Nom" required><br>
    <input type="text" name="prenom" placeholder="Prénom" required><br>
    <input type="email" name="email" placeholder="Email" required><br>
    <input type="text" name="region" placeholder="Region" required><br>
    <input type="password" name="pwd" placeholder="Mot de passe" required><br>
    <button type="submit">Ajouter</button>
</form>
</body>
</html>
