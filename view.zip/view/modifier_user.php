<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Modifier user</title>
</head>
<body>
<h2>Modifier user</h2>
<form method="post" action="../controller/UserController.php?action=modifier&id=<?php echo $data['id']; ?>">
    <input type="text" name="nom" value="<?php echo $data['nom']; ?>" required><br>
    <input type="text" name="prenom" value="<?php echo $data['prenom']; ?>" required><br>
    <input type="email" name="email" value="<?php echo $data['email']; ?>" required><br>
    <button type="submit">Modifier</button>
</form>
</body>
</html>
